Partner Ledger:
=========================================================

Go to Setting / apps and search "Partner Ledger" and Install

And, you are done with installation. Congratulations!
